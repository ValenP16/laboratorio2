/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.basedatos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import java.util.Scanner;
import mundo.Alumno;

/**
 *
 * @author Valentina Peñafiel
 */
public class BaseDatos {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        //Definiendo variables lector y activo
        Scanner lector = new Scanner(System.in);
        boolean activo = true;
        
        //creando el array en el que se va a guardar cada cosa
        ArrayList<Alumno> listadoAlumnos = new ArrayList<Alumno>();
        cargarReporte(listadoAlumnos);
        //Se abre un do-while para que el menu se repita hasta que la bandera sea 5
        do {
            System.out.println("1. Insertar Alumno");
            System.out.println("2. Eliminar Alumno");
            System.out.println("3. Modificar Alumno");
            System.out.println("4. Consultar Alumno");
            System.out.println("5. Reporte Alumno");
            System.out.println("6. Terminar Programa");
            System.out.print("Seleccione una opción: ");
            
            int opcion = lector.nextInt();
           
           
            switch (opcion) {
                case 1:
                 //Se hacen los llamados de cada case, insertar alumno, eliminar, modificar y consultar Alumno.  
                    System.out.println("OPCION 1: INSERTAR ALUMNO");
                    insertarAlumno(listadoAlumnos, lector);
                    break;
                case 2:
                
                    System.out.println("OPCION 2: ELIMINAR ALUMNO");
                    eliminarAlumno(listadoAlumnos, lector);
                    break;
                case 3:
                    System.out.println("OPCION 3: modificar un alumno");
                    modificarAlumno(listadoAlumnos,lector);
                    break;
                case 4:
                    System.out.println("OPCION 4: consultar un alumno");
                    mostrarAlumnos(listadoAlumnos);
                    break;
                 
                case 5:            
                    System.out.println("OPCION 5: Reporte Alumno ");
                    generarReporte(listadoAlumnos);
                    break;    
                    
                case 6:
                    // se cierra el programa                
                    System.out.println("SALIR DEL PROGRAMA");
                    activo = false;
                    break;
          
                default:
                    System.out.println("ups!! no has seleccionado ninguna opcion, intenta de nuevo");
                    break;
            }
            //Cerramos el while
        } while (activo);
         //cerramos el lector
        lector.close();
    }
    
    //Funcion para insertar un nuevo alumno

    public static Alumno insertarAlumno(ArrayList<Alumno> listadoAlumnos, Scanner lector) {
    Alumno nAlumno = new Alumno();
    //Listado de alumnos
    
    System.out.print("Ingrese un nombre: ");
    String nombre = lector.next();
    while (nombre.isEmpty()) {
        System.out.println("El nombre no puede estar en blanco. Por favor, ingrese un nombre.");
        nombre = lector.next();
    }
    nAlumno.setNombre(nombre);
        

    System.out.print("Ingrese un apellido: ");
    String apellido = lector.next();
    while (apellido.isEmpty()) {
        System.out.println("El apellido no puede estar en blanco. Por favor, ingrese un apellido.");
        apellido = lector.next();
    }
    nAlumno.setApellido(apellido);


    System.out.print("Ingrese una cédula: ");
    String cedula = lector.next();
    while (cedula.isEmpty()) {
        System.out.println("La cédula no puede estar en blanco. Por favor, ingrese una cédula.");
        cedula = lector.next();
    }
    nAlumno.setCedula(cedula);

    System.out.print("Ingrese un semestre: ");
    String semestre = lector.next();
    while (semestre.isEmpty()) {
        System.out.println("El semestre no puede estar en blanco. Por favor, ingrese un semestre.");
        semestre = lector.next();
    }
    nAlumno.setSemestre(semestre);

    System.out.print("Ingrese un correo: ");
    String correo = lector.next();
    while (correo.isEmpty()) {
        System.out.println("El correo no puede estar en blanco. Por favor, ingrese un correo.");
        correo = lector.next();
    }
    nAlumno.setCorreo(correo);

    System.out.print("Ingrese un celular: ");
    String celular = lector.next();
    while (celular.isEmpty()) {
        System.out.println("El celular no puede estar en blanco. Por favor, ingrese un celular.");
        celular = lector.next();
    }
    nAlumno.setCelular(celular);
 
    
    
    listadoAlumnos.add(new Alumno(nombre, apellido, cedula,semestre,celular,correo));
    System.out.println("Te has registrado correctamente.");

    return nAlumno;
}
    public static void eliminarAlumno(ArrayList<Alumno> listadoAlumnos, Scanner lector) {
           System.out.println("ingrese la cedula");
           String cEliminar=lector.next();
           lector.nextInt();
           for(Alumno nAlum: listadoAlumnos){
               if(cEliminar.equals(nAlum.getCedula())){
                   listadoAlumnos.remove(nAlum);
                   System.out.println("se ha eliminado");
                   break;
               }else{
                   System.out.println("no se encontro");
               }
           }
    }   
    public static void modificarAlumno(ArrayList<Alumno> listadoAlumnos, Scanner lector) {
    System.out.print("Ingrese la cédula del alumno a modificar: ");
    String cedulaModificar = lector.next();

    boolean encontrado = false;
    for (Alumno alumno : listadoAlumnos) {
        if (alumno.getCedula().equals(cedulaModificar)) {
            System.out.println("modificar datos: " + alumno.getNombre() + " " + alumno.getApellido());

            System.out.print("ingrese un nuevo nombre ");
            String nNombre = lector.next();
            if (!nNombre.isEmpty()) {
                alumno.setNombre(nNombre);
            }

            System.out.print("ingrese un nuevo apellido: ");
            String nApellido = lector.next();
            if (!nApellido.isEmpty()) {
                alumno.setApellido(nApellido);
            }

            System.out.print("Ingrese un nuevo semestre): ");
            String nSemestre = lector.next();
            if (!nSemestre.isEmpty()) {
                alumno.setSemestre(nSemestre);
            }

            System.out.print("Ingrese un nuevo correo: ");
            String nCorreo = lector.next();
            if (!nCorreo.isEmpty()) {
                alumno.setCorreo(nCorreo);
            }

            System.out.print("Ingrese un nuevo celular: ");
            String nCelular = lector.next();
            if (!nCelular.isEmpty()) {
                alumno.setCelular(nCelular);
            }

            System.out.println("Se modificaron los datos correctamente.");
            encontrado = true;
            break;
        }
    }

    if (!encontrado) {
        System.out.println("Hubo un error al buscar este alumno, ingrese la cedula nuevamente.");
    }
}
    
    public static void mostrarAlumnos(ArrayList<Alumno> listadoAlumnos) {
    if (listadoAlumnos.isEmpty()) {
        System.out.println("No hemos encontrado ninguna lista.");
    } else {
        System.out.println("Listado de Alumnos:");
        for (Alumno alumno : listadoAlumnos) {
            System.out.println("Nombre: " + alumno.getNombre());
            System.out.println("Apellido: " + alumno.getApellido());
            System.out.println("Cédula: " + alumno.getCedula());
            System.out.println("Semestre: " + alumno.getSemestre());
            System.out.println("Correo: " + alumno.getCorreo());
            System.out.println("Celular: " + alumno.getCelular());
            System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><>");
        }
    }
}
    
   public static void generarReporte(ArrayList<Alumno> listaAlumnos) {
    try {
        File archivo = new File("Reporte_data.txt");
        
        if (!archivo.exists()) {
            archivo.createNewFile();
        }

        // Crear una nueva lista para almacenar alumnos con cédulas únicas
        ArrayList<Alumno> listaAlumnosUnicos = new ArrayList<>();

        // Filtrar y agregar solo los alumnos con cédulas únicas a la nueva lista
        for (Alumno alumno : listaAlumnos) {
            boolean cedulaRepetida = false;
            for (Alumno alumnoUnico : listaAlumnosUnicos) {
                if (alumnoUnico.getCedula().equals(alumno.getCedula())) {
                    cedulaRepetida = true;
                    break;
                }
            }
            if (!cedulaRepetida) {
                listaAlumnosUnicos.add(alumno);
            }
        }

        try (FileWriter writer = new FileWriter(archivo) // Crear un nuevo archivo, sobrescribir contenido
        ) {
            for (Alumno alumno : listaAlumnosUnicos) {
                writer.write("Nombre: " + alumno.getNombre() + "\n");
                writer.write("Apellido: " + alumno.getApellido() + "\n");
                writer.write("Cédula: " + alumno.getCedula() + "\n");
                writer.write("Semestre: " + alumno.getSemestre() + "\n");
                writer.write("Correo: " + alumno.getCorreo() + "\n");
                writer.write("Celular: " + alumno.getCelular() + "\n");
                writer.write("---------------------------\n");
            }
        }
        System.out.println("Reporte generado exitosamente.");
    } catch (IOException e) {
        System.out.println("Error al generar el reporte: " + e.getMessage());
    }
   }
   //Agregar alumno
    public static void agregarAlumno (ArrayList<Alumno> listadoAlumnos, Scanner lector){
        
      System.out.println( "<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                    System.out.println("Introduce la cedula del alumno");
                    String cedula = lector.next();
                    
                    System.out.println("Introduce el nombre del estudiante");
                    String nombre = lector.next();
                    
                    System.out.println("Introduce el apellido del estudiante");
                    String apellido = lector.next();
                    
                    System.out.println("Introduce el correo del estudiante ");
                    String correo = lector.next();
                    
                    System.out.println("Introduce el celular del estudiante ");
                    String celular = lector.next();
                    
                    System.out.println("Introduce el semestre del estudiante");
                    String semestre = lector.next();
                    
                      System.out.println( "<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                    
                    // Se crea un objeto para guardar la información de cada alumno
                    Alumno a = new Alumno(cedula, nombre, apellido, correo, celular, semestre);
                    
                    a.setCedula(cedula);
                    a.setNombre(nombre);
                    a.setApellido(apellido);
                    a.setCorreo(correo);
                    a.setCelular(celular);
                    a.setSemestre(semestre);
                     
                    // se agrega el valor del objeto al listaArray
                    listadoAlumnos.add(a);                     
    }
     //método para eliminar estudiante, con las entradas del array y el scanner
   public static void eliminarAlumno (ArrayList<Alumno>listadoAlumnos){
          System.out.println( "<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
        if (!listadoAlumnos.isEmpty()){ 
        System.out.println("Digite la cedula del Alumno que desea eliminar");
            String cedulaE = lector.next();
        boolean encontro= false;
        
          //Creamos el ciclo for para recorrer el array
        for(Alumno estu: listadoAlumnos){
            
            if( cedulaE.equals(estu.getCedula())){
                  listadoAlumnos.remove(estu);
                  System.out.println("Se eliminó al alumno con éxito");
                  encontro=true;
                  break; 
            }  
        }
        //concidicional si no se encontró la cedula
        if(encontro == false){
            System.out.println("No existe el estudiante");
        }
        }else {
            //El array esta vacio
            System.out.println("No hay estudiantes");
        }
         System.out.println( "<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
        
      
    }
    
    //metodo para modificar a un estudiante
    public static void modificarAlumno(ArrayList<Alumno>listadoAlumnos){
        
          if (!listadoAlumnos.isEmpty()){
            System.out.println( "<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
        System.out.println("Digite la cedula del Alumno que desea modificar");
            String cedulaM = lector.next();
        boolean encontro= false;
        
          
        for(Alumno estudiante: listadoAlumnos){
            
            if( cedulaM.equals(estudiante.getCedula())){
                
                System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                
                
                System.out.println("Digite la nueva cedula");
              
                String cedulaN = lector.next();
            
                estudiante.setCedula(cedulaN);
            
                System.out.println("Digite el nuevo nombre");
        
                String nombreN = lector.next();
         
                estudiante.setNombre(nombreN);
                
                System.out.println("Digite el nuevo apellido");
              
                String apellidoN = lector.next();
  
                estudiante.setApellido(apellidoN);
                

                System.out.println("Digite el nuevo correo ");
                
                String correoN = lector.next();

                estudiante.setCorreo(correoN);
                
                System.out.println("Digite el nuevo celular ");

                String celularN = lector.next();
                
                estudiante.setCelular(celularN);
                
           
                System.out.println("Digite el nuevo semestre ");
                
                String semestreN = lector.next();
                
                estudiante.setSemestre(semestreN);
                
                System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                
                  encontro=true;
                  break; 
            }  
        }
        //concidicional si no se encontró la cedula
        if(encontro == false){
            System.out.println("No existe el estudiante");
        }
        }else {
            System.out.println("No hay estudiantes");
        }
        
          System.out.println( "<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
    }
    
    //Opcion para mostrar los estudiantes registrados
    public static void consultarAlumnos (ArrayList<Alumno>listadoAlumnos){
         System.out.println( "<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
        if(listadoAlumnos.isEmpty()){
            
            System.out.println("No hay alumnos");
              System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
        }else{

            int nAlumno = listadoAlumnos.size();
            
           
              if(listadoAlumnos.size()==1){
                  
                  System.out.println("Hay "+ nAlumno + " alumno");
                  System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                  
              }else{
                 
                  System.out.println("Hay "+ nAlumno + " alumnos");
                  System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                  
              }
            for(Alumno listaAlumno: listadoAlumnos ){
               
                System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                    System.out.println("Alumno "+ nAlumno);
                    System.out.println("Cedula: " + listaAlumno.getCedula());
                    System.out.println("Nombre: " + listaAlumno.getNombre());
                    System.out.println("Apellido: " + listaAlumno.getApellido());
                    System.out.println("Correo: " + listaAlumno.getCorreo());
                    System.out.println("Celular: " + listaAlumno.getCelular());
                    System.out.println("Semestre: " + listaAlumno.getSemestre());
                    System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
     
                    nAlumno--;
                
            }
            
        }
          System.out.println( "<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
    }
    
     //Reporte por semestre 
    public static void generarReporteSemestre (ArrayList<Alumno> listadoAlumnos) throws FileNotFoundException{
        
        File archivo = new File(".Reporte_data.txt");
        
        PrintWriter pluma = new PrintWriter(archivo);
         if(!listadoAlumnos.isEmpty()){
        
        System.out.println("Digite el semestre del cual desea generar el reporte");
        
        String semetreR = lector.next();
            
            System.out.println("Se generó el archivo");
               //Escribimos la pluma para el archivo txt 
        pluma.println("Reporte Alumnos por semestre");
        pluma.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
            for(Alumno listaEstu: listadoAlumnos  ){
                
                
                if(listaEstu.getSemestre().equals (semetreR)){
                
                pluma.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                pluma.println("Cedula: " + listaEstu.getCedula());
                pluma.println(","+ "Nombre: " + listaEstu.getNombre());
                pluma.println("," +"Apellido: " + listaEstu.getApellido());
                pluma.println(","+ "Correo: " + listaEstu.getCorreo());
                pluma.println("," +"Celular: " + listaEstu.getCelular());
                pluma.println("," +"Semestre: " + listaEstu.getSemestre());
                pluma.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                    }
                
        }  
             pluma.close();
             
        }else{
             System.out.println("No hay estudiantes");
        }  
        
    }
    
     //método para cargar archivos

    /**
     *
     * @param listadoAlumnos
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static void cargarReporte (ArrayList<Alumno> listadoAlumnos) throws FileNotFoundException, IOException{
        
        //Ubicacion donde leer
        File archivo = new File ("./data/Reporte.txt");
        
        try (FileReader fr = new FileReader (archivo)) {
            
            //Variable donde se va a guardar el reporte
           BufferedReader lc = new BufferedReader(fr);
            
            String linea;
            
            while((linea= lc.readLine()) != null){
                
                //Array donde se guardan los datos leidos
                String [] datos = linea.split(",");
                
                String cedula = datos[0].trim();
                String nombre = datos[1].trim();
                String apellido= datos[2].trim();
                String correo = datos[3].trim();
                String celular = datos[4].trim();
                String semestre = datos[5].trim();
                
                Alumno nuevo = new Alumno(cedula, nombre, apellido, semestre, correo, celular);
                listadoAlumnos.add(nuevo);
            }
            
            System.out.println("Se cargo exitosamente el reporte");
        }catch(FileNotFoundException e ){
            
            System.out.println("No se encontró el archivo de lectura");
            
        }

    }
    //Opcion para borrar el reporte de los estudiantes 
    public static void borrarReporte (ArrayList<Alumno>listadoAlumnos){
        
        if(!listadoAlumnos.isEmpty()){
                
        //limpiamos el array
        listadosAlumnos.clear();
        
        System.out.println("Se ha borrado el contenido del archivo con éxito");
        }else{
            
            System.out.println("Se encuentra vacio el archivo");     
        } 
    }
}

